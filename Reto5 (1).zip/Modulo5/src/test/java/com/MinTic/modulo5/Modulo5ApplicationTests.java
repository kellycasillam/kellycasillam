package com.MinTic.modulo5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Modulo5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
