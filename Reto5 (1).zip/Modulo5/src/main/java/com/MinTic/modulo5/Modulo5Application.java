package com.MinTic.modulo5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Modulo5Application {

	public static void main(String[] args) {
		SpringApplication.run(Modulo5Application.class, args);
	}

}
